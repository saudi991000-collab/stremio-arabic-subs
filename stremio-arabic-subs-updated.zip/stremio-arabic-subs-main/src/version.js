// Single source of truth for the release number. package.json, the manifest,
// the configure page and every outgoing User-Agent read from here.
export const VERSION = "3.13.1";
export const USER_AGENT = `ArabicEliteSubs v${VERSION}`;
