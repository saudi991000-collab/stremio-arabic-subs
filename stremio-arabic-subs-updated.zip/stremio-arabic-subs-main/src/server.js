import http from "node:http";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { createHash, randomUUID, timingSafeEqual } from "node:crypto";
import { monitorEventLoopDelay } from "node:perf_hooks";
import { readConfig } from "./config.js";
import { logger } from "./logger.js";
import { manifest } from "./manifest.js";
import { parseExtra, parseReleaseName } from "./media.js";
import { alignMediaLocally, alignMediaToFilename, identityUnresolved, resolveVideoId } from "./id-resolver.js";
import { arabicFansubTeam, madeForThisVideo, rankCandidates, releaseFit, releaseMatched, resultLabel, stableKey } from "./ranker.js";
export { madeForThisVideo, releaseFit };
import { signSubtitleToken, verifySubtitleToken } from "./token.js";
import { convertToFormat, detectTextFormat, normalizeSubtitle } from "./subtitle.js";
import { Cache } from "./cache.js";
import { JsonStore, UpstashKv, deepFreeze, mergeSearchEntries } from "./store.js";
import { runInBackground } from "./http.js";
import { assessSubtitle } from "./quality.js";
import { OpenSubtitlesProvider } from "./providers/opensubtitles.js";
import { OpenSubtitlesOrgProvider } from "./providers/opensubtitles-org.js";
import { SubDLProvider } from "./providers/subdl.js";
import { SubSourceProvider } from "./providers/subsource.js";
import { ArabicSubsProvider } from "./providers/arabicsubs.js";
import { StremioV3Provider } from "./providers/stremio-v3.js";
import { WyzieProvider } from "./providers/wyzie.js";
import { SubKongProvider } from "./providers/subkong.js";
import { MiraiAnimeProvider } from "./providers/miraianime.js";
import { useAnimeNameStore } from "./anime-titles.js";
import { AniKotoProvider } from "./providers/anikoto.js";
import { TheSubtitleDbProvider } from "./providers/thesubtitledb.js";
import { MoraProvider } from "./providers/mora.js";
import { Subf2mProvider } from "./providers/subf2m.js";
import { YifySubtitlesProvider } from "./providers/yifysubtitles.js";
import { TvSubtitlesProvider } from "./providers/tvsubtitles.js";
import { MovieSubtitlesProvider } from "./providers/moviesubtitles.js";
import { MultiProvider } from "./providers/multi.js";
import { deepAnalyzeCandidates, isTransientError, normalizedSubtitleCacheKey, retryableRejection, verdictKey } from "./deep-analyzer.js";
import { isIdentityTransform, retimeSubtitle } from "./timing.js";
import { TimingMemory, itemId } from "./timing-memory.js";
import { polishSubtitle } from "./polish.js";
import {
  CompanionRegistry,
  discoverWindowsStremioHlsSession,
  discoverWindowsStremioSession,
  isAllowedCompanionOrigin,
  isLoopbackAddress,
  LocalMediaAnalyzer
} from "./companion.js";

const moduleDirectory = path.dirname(fileURLToPath(import.meta.url));
const embeddedConfigurePage = `<!doctype html>
<html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>ترجمة النخبة</title><style>body{margin:0;background:#0d0b18;color:#fff;font-family:system-ui;display:grid;place-items:center;min-height:100vh}.card{max-width:620px;margin:24px;padding:34px;border:1px solid #7c5cff;border-radius:22px;background:#171328;text-align:center}h1{margin-top:0}p{color:#cbc5df;line-height:1.8}.button{display:inline-block;margin:10px;padding:14px 24px;border-radius:14px;background:#7c5cff;color:white;text-decoration:none;font-weight:700}.url{direction:ltr;word-break:break-all;background:#0b0912;padding:12px;border-radius:10px}</style></head>
<body><main class="card"><h1>⭐ ترجمة النخبة</h1><p>حتى 30 ترجمة عربية بشرية مرتبة، مع دعم صيغ الترجمة النصية وتحويلها تلقائياً إلى صيغة متوافقة مع Stremio.</p><a class="button" href="{{STREMIO_URL}}">تثبيت في Stremio</a><a class="button" href="{{SRT_STREMIO_URL}}">تثبيت نسخة SRT (تلفزيون/آيباد)</a><p>إذا لم يفتح الزر، انسخ رابط الـManifest:</p><div class="url">{{MANIFEST_URL}}</div><p>الإصدار {{VERSION}}</p></main></body></html>`;

const srtManifest = {
  ...manifest,
  name: `${manifest.name} (SRT)`,
  description: `${manifest.description} نسخة SRT: كل الترجمات بصيغة SRT لأجهزة التلفزيون والآيباد.`
};

const SECURITY_HEADERS = { "X-Content-Type-Options": "nosniff", "Referrer-Policy": "no-referrer" };

function json(response, status, data, extraHeaders = {}) {
  const headers = { "Content-Type": "application/json; charset=utf-8", "Access-Control-Allow-Origin": "*", ...SECURITY_HEADERS, ...extraHeaders };
  // A header explicitly set to undefined (companion routes) is removed.
  for (const [name, value] of Object.entries(headers)) if (value === undefined) delete headers[name];
  response.writeHead(status, headers);
  response.end(JSON.stringify(data));
}

function html(response, status, data) {
  response.writeHead(status, {
    "Content-Type": "text/html; charset=utf-8",
    ...SECURITY_HEADERS,
    "Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'; img-src https: data:; script-src 'unsafe-inline'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'"
  });
  response.end(data);
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;", "'": "&#39;" })[char]);
}

function emptySubtitle(extension) {
  if (extension === "vtt") return { contentType: "text/vtt; charset=utf-8", body: "WEBVTT\n\n" };
  if (extension === "ass" || extension === "ssa") {
    return { contentType: "text/x-ssa; charset=utf-8", body: "[Script Info]\nTitle: Empty fallback\n[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n" };
  }
  return { contentType: "application/x-subrip; charset=utf-8", body: "" };
}

async function readJsonBody(request, maxBytes = 16384) {
  const chunks = [];
  let size = 0;
  for await (const chunk of request) {
    size += chunk.length;
    if (size > maxBytes) throw new Error("Request body is too large");
    chunks.push(chunk);
  }
  return JSON.parse(Buffer.concat(chunks).toString("utf8") || "{}");
}

function baseUrl(request, config) {
  if (config.publicBaseUrl) return config.publicBaseUrl;
  const forwardedProtocol = String(request.headers["x-forwarded-proto"] || "").split(",")[0].trim();
  const protocol = forwardedProtocol === "https" ? "https" : "http";
  // Only a syntactically valid host may be reflected into generated URLs.
  const host = String(request.headers.host || "");
  const safeHost = /^[a-z0-9.-]+(?::\d{1,5})?$/i.test(host) || /^\[[0-9a-f:]+\](?::\d{1,5})?$/i.test(host) ? host : `127.0.0.1:${config.port}`;
  return `${protocol}://${safeHost}`;
}

function extensionOf(candidate) {
  if (candidate?.actualFormat) return /^(?:srt|vtt|ass|ssa)$/.test(candidate.actualFormat) ? candidate.actualFormat : "srt";
  const fileName = typeof candidate === "string" ? candidate : candidate?.fileName || candidate?.release || "";
  const format = String(fileName).toLowerCase().match(/\.(srt|vtt|ass|ssa|smi|sami|sbv|ttml|dfxp|sub)$/)?.[1] || "srt";
  return /^(?:srt|vtt|ass|ssa)$/.test(format) ? format : "srt";
}

export const PROVIDER_LABELS = {
  opensubtitles: "OpenSubtitles",
  "opensubtitles-org": "OpenSubtitles.org",
  moviesubtitles: "MovieSubtitles",
  subdl: "SubDL",
  subsource: "SubSource",
  arabicsubs: "ArabicSubs",
  wyzie: "Wyzie",
  thesubtitledb: "TheSubtitleDB",
  subf2m: "Subf2m",
  mora: "Mora",
  subkong: "SubKong",
  miraianime: "MiraiAnime",
  anikoto: "AniKoto",
  yifysubtitles: "YIFY",
  tvsubtitles: "TVsubtitles",
  "stremio-v3": "OpenSubtitles v3"
};

// Relative trust used only as a late tie-breaker in ordering.
const PROVIDER_RELIABILITY = {
  opensubtitles: 6, "opensubtitles-org": 5, subdl: 6, subsource: 6, arabicsubs: 6, thesubtitledb: 5,
  subf2m: 4, mora: 5, miraianime: 5, yifysubtitles: 3, subkong: 3, wyzie: 3, "stremio-v3": 4, anikoto: 2
};

const PLATFORM_LABELS = {
  netflix: "Netflix",
  crunchyroll: "Crunchyroll",
  amazon: "Amazon",
  max: "Max",
  disney: "Disney+",
  hulu: "Hulu",
  "apple-tv": "Apple TV+",
  paramount: "Paramount+",
  peacock: "Peacock",
  shahid: "Shahid",
  osn: "OSN+",
  hidive: "HIDIVE"
};

function compactReleaseName(candidate) {
  // Prefer the full file name when the release field is only its tail
  // ("1080p.Bluray.X264-EVO" vs "Movie.2022.1080p.Bluray.X264-EVO.srt").
  const fileStem = String(candidate.fileName || "").replace(/^.*[\\/]/, "").replace(/\.[a-z0-9]{2,4}$/i, "");
  // SubSource joins every compatible release with " | "; show the first.
  const release = String(candidate.release || "").split(" | ")[0].trim();
  const name = !release || (fileStem && fileStem.toLowerCase().includes(release.replace(/^[.\s-]+|[.\s-]+$/g, "").toLowerCase()) && fileStem.length > release.length)
    ? fileStem || release
    : release;
  return String(name || candidate.fileName || "").split(" | ")[0]
    .replace(/^.*[\\/]/, "")
    .replace(/\.(?:srt|vtt|ass|ssa|smi|sami|sbv|ttml|dfxp|sub)$/i, "")
    .replace(/[\u0000-\u001f]/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 160);
}

export function badgesFor(candidate) {
  const matched = releaseMatched(candidate);
  const team = arabicFansubTeam(candidate);
  // 🎨 requires content inspection: a ".ass" name alone is not enough.
  const styled = Boolean(candidate.deepAnalyzed && candidate.styled);
  return { matched, team, styled };
}

// 🎯 = timing checked against this exact video (its hash, its own audio or
// embedded track) or confirmed by two independent references; ⚠️ = the
// references disagree, so the timing may be off.
const VIDEO_REFERENCE_KINDS = new Set(["exact-hash", "embedded", "embedded-sample", "audio-whisper"]);
export function timingCheck(candidate = {}) {
  const reasons = candidate.reasons || [];
  if (reasons.includes("timing-conflict") || reasons.includes("timing-mismatch")) return "conflict";
  if (reasons.includes("exact-hash")) return "verified";
  const score = Number(candidate.timingScore) || 0;
  if (score >= 0.75 && (VIDEO_REFERENCE_KINDS.has(candidate.timingReferenceKind) || reasons.includes("timing-consensus"))) return "verified";
  return "";
}

const SOURCE_LABELS = {
  bluray: "BD", remux: "BD", "web-dl": "WEB", webrip: "WEB", web: "WEB", hdtv: "TV", dvdrip: "DVD", dvd: "DVD"
};

// Short label for TV screens: number, marks, who made it, and which video
// it was made for. "3 ✅ Memories • BD 🎨"
// ✅ made for this version · 📌 picked before · ⭐ rated · 🎯 timing checked
// · ⏱ timing corrected · ⚠️ timing doubtful · 🎨 styled · 👎 rated down
export function detailedResultLabel(candidate, index) {
  const parsed = parseReleaseName(candidate.fileName || candidate.release || "");
  const { team, styled } = badgesFor(candidate);
  const marks = [
    candidate.chosen === 2 ? "📌" : "",
    candidate.userRating > 0 ? "⭐" : "",
    madeForThisVideo(candidate) ? "✅" : "",
    timingCheck(candidate) === "verified" ? "🎯" : "",
    candidate.timingCorrected ? "⏱" : "",
    timingCheck(candidate) === "conflict" ? "⚠️" : "",
    candidate.userRating < 0 ? "👎" : ""
  ].filter(Boolean).join("");
  // MiraiAnime hosts many teams' files: show the team named in the zip.
  const shownTeam = (candidate.provider === "miraianime" && /^\[([^\]]{2,30})\]/.exec(candidate.fileName || "")?.[1]) || team;
  const who = shownTeam || PROVIDER_LABELS[candidate.provider] || candidate.provider || "Custom";
  const platform = PLATFORM_LABELS[parsed.platform];
  // Release group as written in the name ("-NTb", "[DeadFish]"), unless it
  // repeats the team or platform already shown.
  const groupName = parsed.group && /^[a-z0-9]{2,15}$/i.test(parsed.group) &&
    parsed.group !== String(shownTeam || "").toLowerCase() && parsed.group !== String(platform || "").toLowerCase()
    ? (String(candidate.fileName || candidate.release || "").match(new RegExp(`(?:^|[-\\[ .])(${parsed.group})(?=$|[\\]. ])`, "i"))?.[1] || parsed.group)
    : "";
  const video = [platform || SOURCE_LABELS[parsed.source], parsed.resolution, groupName].filter(Boolean).join(" ");
  const details = [who, video].filter(Boolean).join(" • ");
  return `${index + 1}${marks ? ` ${marks}` : ""} ${details}${styled ? " 🎨" : ""}`;
}

// URL-safe version of the label for the subtitle link's final path segment.
export function readableUrlName(label) {
  const clean = String(label || "subtitle")
    .replace(/[\\/?#%]/g, " ")
    .replace(/[\u0000-\u001f]/g, "")
    .replace(/\s+/g, " ")
    .trim();
  // Cut by code points so an emoji is never split into a lone surrogate.
  const text = Array.from(clean).slice(0, 140).join("").trim() || "subtitle";
  return encodeURIComponent(text);
}

function displayBadgeProfile(candidate) {
  const { matched, team, styled } = badgesFor(candidate);
  return {
    // 💪👍 count as two visible badges, followed by 🇸🇦 then 🎨.
    count: (matched ? 2 : 0) + (team ? 1 : 0) + (styled ? 1 : 0),
    matched,
    arabicTeam: Boolean(team),
    styled
  };
}

// Final, deterministic display order (see README "Ranking").
export function sortForDisplay(candidates) {
  return candidates
    .map((candidate) => ({ candidate, badges: displayBadgeProfile(candidate) }))
    .sort((a, b) =>
      // The viewer's own 👍 / 👎 from the /timing page come first.
      (b.candidate.userRating || 0) - (a.candidate.userRating || 0) ||
      // The file picked for this episode before.
      Number(b.candidate.chosen === 2) - Number(a.candidate.chosen === 2) ||
      // ⚠️ timing goes below the rest.
      Number(timingCheck(a.candidate) === "conflict") - Number(timingCheck(b.candidate) === "conflict") ||
      // Exact file/release match first, then the team picked last in this
      // series for translator consistency, then closest release attributes.
      Number(releaseFit(b.candidate) >= 300) - Number(releaseFit(a.candidate) >= 300) ||
      Number(b.candidate.chosen === 1) - Number(a.candidate.chosen === 1) ||
      releaseFit(b.candidate) - releaseFit(a.candidate) ||
      b.badges.count - a.badges.count ||
      Number(timingCheck(b.candidate) === "verified") - Number(timingCheck(a.candidate) === "verified") ||
      Number(b.badges.matched) - Number(a.badges.matched) ||
      Number(b.badges.arabicTeam) - Number(a.badges.arabicTeam) ||
      Number(b.badges.styled) - Number(a.badges.styled) ||
      Number(Boolean(b.candidate.reasons?.includes("exact-hash"))) - Number(Boolean(a.candidate.reasons?.includes("exact-hash"))) ||
      Number(Boolean(b.candidate.deepAnalyzed)) - Number(Boolean(a.candidate.deepAnalyzed)) ||
      (b.candidate.timingScore || 0) - (a.candidate.timingScore || 0) ||
      (b.candidate.syncScore || 0) - (a.candidate.syncScore || 0) ||
      (b.candidate.humanScore ?? 0.5) - (a.candidate.humanScore ?? 0.5) ||
      (PROVIDER_RELIABILITY[b.candidate.provider] || 1) - (PROVIDER_RELIABILITY[a.candidate.provider] || 1) ||
      (b.candidate.qualityScore || 0) - (a.candidate.qualityScore || 0) ||
      stableKey(a.candidate).localeCompare(stableKey(b.candidate))
    )
    .map(({ candidate }) => candidate);
}

function selectDiverseCandidates(candidates, limit) {
  const selected = [];
  const deferred = [];
  const counts = new Map();
  const perProvider = Math.max(3, Math.ceil(limit / 4));
  for (const candidate of candidates) {
    const providerId = candidate.provider || "default";
    const count = counts.get(providerId) || 0;
    if (count < perProvider) {
      selected.push(candidate);
      counts.set(providerId, count + 1);
    } else deferred.push(candidate);
    if (selected.length >= limit) return selected;
  }
  for (const candidate of deferred) {
    selected.push(candidate);
    if (selected.length >= limit) break;
  }
  return selected;
}

// After inspection: (1) the same file mirrored by several providers (same
// release name, cue count within 1%, same length) is shown once; (2) a verified
// subtitle far shorter or longer than the others for the same video (a
// featurette, a partial file, a different cut) is dropped, and so is one
// with a long untranslated stretch.
export function dropDuplicatesAndOutliers(candidates, videoDurationSeconds) {
  const durations = candidates.filter((item) => item.deepAnalyzed && item.subtitleDurationSeconds > 0).map((item) => item.subtitleDurationSeconds).sort((a, b) => a - b);
  const reference = Number(videoDurationSeconds) > 60 ? Number(videoDurationSeconds) : durations.length >= 4 ? durations[Math.floor(durations.length / 2)] : 0;
  const kept = [];
  for (const candidate of candidates) {
    if (reference && candidate.deepAnalyzed && candidate.subtitleDurationSeconds > 0 && !candidate.reasons?.includes("exact-hash")) {
      const ratio = candidate.subtitleDurationSeconds / reference;
      if (ratio < 0.75 || ratio > 1.5) continue;
    }
    // Part of the dialogue was never translated (long gap, or far shorter
    // than the video): not listed.
    if (candidate.deepAnalyzed && !candidate.reasons?.includes("exact-hash") &&
      candidate.reasons?.some((reason) => reason === "q:incomplete" || reason === "q:untranslated-gap")) continue;
    const name = normalizeReleaseKey(candidate);
    const duplicate = candidate.deepAnalyzed && kept.some((item) => item.deepAnalyzed && item.provider !== candidate.provider &&
      normalizeReleaseKey(item) === name &&
      Math.abs((item.cueCount || 0) - (candidate.cueCount || 0)) <= Math.max(2, (candidate.cueCount || 0) * 0.01) &&
      Math.abs((item.subtitleDurationSeconds || 0) - (candidate.subtitleDurationSeconds || 0)) <= 3);
    if (!duplicate) kept.push(candidate);
  }
  return kept;
}

// The same subtitle uploaded to several sources (or twice under different
// names) is listed once: same words and the same length means the same file.
// A copy re-timed for another release keeps its own entry.
export function dropSameFiles(candidates) {
  const seen = new Set();
  return candidates.filter((candidate) => {
    if (!candidate.contentHash || !candidate.subtitleDurationSeconds) return true;
    const key = `${candidate.contentHash}:${Math.round(candidate.subtitleDurationSeconds / 3)}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function normalizeReleaseKey(candidate) {
  return compactReleaseName(candidate).toLowerCase().replace(/[^a-z0-9]+/g, "");
}

function within(promise, timeoutMs, fallback) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      if (arguments.length >= 3) resolve(fallback);
      else reject(new Error("deadline exceeded"));
    }, Math.max(1, timeoutMs));
    promise.then((value) => {
      clearTimeout(timer);
      resolve(value);
    }, (error) => {
      clearTimeout(timer);
      reject(error);
    });
  });
}

function fallbackCandidates(eligible, candidate, extension, limit) {
  const all = eligible.filter((item) => item !== candidate);
  const pool = [
    ...all.filter((item) => item.deepAnalyzed && extensionOf(item) === extension),
    ...all.filter((item) => item.deepAnalyzed && extensionOf(item) !== extension),
    ...all.filter((item) => !item.deepAnalyzed)
  ];
  const selected = [candidate];
  const providers = new Set([candidate.provider || "opensubtitles"]);
  for (const item of pool) {
    const providerId = item.provider || "opensubtitles";
    if (providers.has(providerId)) continue;
    selected.push(item);
    providers.add(providerId);
    if (selected.length >= limit) return selected;
  }
  for (const item of pool) {
    if (selected.includes(item)) continue;
    selected.push(item);
    if (selected.length >= limit) break;
  }
  return selected;
}

function isSeasonPack(candidate) {
  return Boolean(candidate?.reasons?.includes("season-pack"));
}

// Season packs worth opening: the pack names this season (or the provider
// says so). "Complete series" archives without a season are left out.
// A downloaded and verified Arabic file that the provider itself filed under
// this exact episode is trusted with a lower name score: generic names such as
// "01 - Pilot-ara.srt" scored 68 and were hidden although they were correct.
export function verifiedThreshold(candidate, minConfidence = readConfigMin) {
  const reasons = candidate?.reasons || [];
  const providerConfirmed = reasons.includes("episode-metadata") && reasons.includes("catalog-match");
  return providerConfirmed ? Math.min(minConfidence, 60) : minConfidence;
}
let readConfigMin = 70;

// Only a pack that the provider did not file under this episode must prove
// it holds the episode by file name; an episode-scoped result named after
// its season (Wyzie, SubDL) is a single episode file.
export function strictSeasonPack(candidate) {
  return Boolean(candidate?.reasons?.includes("season-pack") && candidate.episodeScoped !== true);
}

export function seasonPackForEpisode(candidate, media) {
  if (!isSeasonPack(candidate) || media?.type !== "series") return false;
  const name = String(candidate.fileName || candidate.release || "");
  const season = candidate.featureDetails?.seasonNumber ?? parseReleaseName(name).season ??
    name.match(/(?:^|[^a-z0-9])(?:season[ ._-]*|s)0*(\d{1,2})(?![0-9]|[ ._-]*(?:e|ep|x)\d)/i)?.[1];
  return season != null && Number(season) === Number(media.season);
}

export function timingTransform(candidate, minConfidence = 0.6) {
  const score = Number(candidate?.timingScore);
  if (!candidate || candidate.reasons?.includes("exact-hash") || !Number.isFinite(score) || score < minConfidence) return undefined;
  if (!candidate.timingModel || candidate.timingModel === "none") {
    // Legacy tokens (3.5.x) carried scale/offset without a model name.
    if (candidate.timingModel === "none") return undefined;
  }
  const transform = Array.isArray(candidate.timingSegments) && candidate.timingSegments.length
    ? { segments: candidate.timingSegments.map((segment) => ({ start: segment.start ?? -1e9, end: segment.end ?? 1e9, scale: segment.scale, offset: segment.offset })) }
    : { scale: Number(candidate.timingScale) || 1, offset: Number(candidate.timingOffset) || 0 };
  if (isIdentityTransform(transform)) return undefined;
  return { ...transform, score, reference: candidate.timingReferenceKind || "reference" };
}

// JSON cannot carry Infinity; piecewise segments use large finite bounds.
function serializableTransform(transform) {
  if (!transform?.segments) return transform;
  return {
    ...transform,
    segments: transform.segments.map((segment) => ({
      start: Number.isFinite(segment.start) ? Number(segment.start.toFixed(3)) : -1e9,
      end: Number.isFinite(segment.end) ? Number(segment.end.toFixed(3)) : 1e9,
      scale: Number(segment.scale.toFixed(7)),
      offset: Number(segment.offset.toFixed(3))
    }))
  };
}

// A list with few subtitles (often a new episode whose Arabic translation
// is not out yet) is searched again after an hour instead of six.
export function freshForMs(entry, config) {
  const full = config.cacheTtlSeconds * 1000;
  return (entry?.candidates?.length || 0) < 5 ? Math.min(full, 3600000) : full;
}

function searchKey(type, id, extra) {
  const filename = path.basename(String(extra.filename || "")).toLowerCase().slice(0, 240);
  // v4: media identity carries Kitsu romaji/English titles (needed without a
  // filename); v3 entries could hold an abbreviated title.
  return `search:v8:${type}:${id}:${filename}:${String(extra.videoHash || "").toLowerCase()}:${extra.videoSize || ""}`;
}

export function buildProviders(config) {
  const disabled = new Set(config.disabledProviders || []);
  const providers = [
    ...(config.openSubtitles.apiKey ? [new OpenSubtitlesProvider(config.openSubtitles)] : []),
    ...(config.openSubtitlesOrg?.enabled !== false ? [new OpenSubtitlesOrgProvider(config.openSubtitlesOrg)] : []),
    ...(config.subdl.apiKey ? [new SubDLProvider(config.subdl)] : []),
    ...(config.subsource.apiKey ? [new SubSourceProvider(config.subsource)] : []),
    ...(config.arabicSubs.apiKey ? [new ArabicSubsProvider(config.arabicSubs)] : []),
    ...(config.wyzie.apiKey ? [new WyzieProvider(config.wyzie)] : []),
    new TheSubtitleDbProvider(config.theSubtitleDb),
    new Subf2mProvider(),
    new MoraProvider(config.mora),
    new SubKongProvider(config.subkong),
    new MiraiAnimeProvider(config.miraianime),
    ...(config.anikoto?.enabled !== false ? [new AniKotoProvider(config.anikoto)] : []),
    ...(config.yify?.enabled !== false ? [new YifySubtitlesProvider()] : []),
    ...(config.tvsubtitles?.enabled !== false ? [new TvSubtitlesProvider()] : []),
    new MovieSubtitlesProvider(),
    new StremioV3Provider()
  ];
  return providers.filter((provider) => !disabled.has(provider.id));
}

export async function createAddonServer({ config = readConfig(), provider, cache, stores } = {}) {
  readConfigMin = config.minConfidence;
  const configuredProviders = provider ? [] : buildProviders(config);
  const actualProvider = provider || new MultiProvider(configuredProviders, { providerTimeoutMs: config.providerHardTimeoutMs });
  const expectedProviders = actualProvider.names || [];
  const actualCache = cache || new Cache(config.cacheDirectory, config.cacheTtlSeconds);
  let remote = null;
  if (config.upstash) {
    try {
      remote = new UpstashKv(config.upstash);
    } catch (error) {
      logger.warn("remote cache disabled", { reason: error.message });
    }
  }
  const searchStore = stores?.search || new JsonStore({ directory: config.cacheDirectory, namespace: "search", ttlSeconds: config.searchStaleSeconds, remote });
  const verdictStore = stores?.verdicts || new JsonStore({ directory: config.cacheDirectory, namespace: "verdicts", ttlSeconds: config.verdictTtlSeconds, remote });
  const timingStore = stores?.timing || new JsonStore({ directory: config.cacheDirectory, namespace: "timing", ttlSeconds: config.timingMemoryTtlSeconds, remote });
  // What the viewer picked: the subtitle chosen for each episode, the
  // translator/team preferred per series, and which series are being watched.
  const choiceStore = stores?.choices || new JsonStore({ directory: config.cacheDirectory, namespace: "choices", ttlSeconds: 180 * 24 * 3600, remote });
  useAnimeNameStore(stores?.anime || new JsonStore({ directory: config.cacheDirectory, namespace: "anime", ttlSeconds: 30 * 24 * 3600, remote }));
  const timingMemory = new TimingMemory(timingStore);
  const companion = new CompanionRegistry();
  const mediaAnalyzer = new LocalMediaAnalyzer({
    ffprobePath: config.ffprobePath,
    ffmpegPath: config.ffmpegPath,
    whisperPath: config.whisperPath,
    whisperModelPath: config.whisperModelPath,
    whisperSampleSeconds: config.whisperSampleSeconds
  });
  await actualCache.init();
  const backgroundTasks = new Set();
  // Listings currently being answered; background validation waits while > 0.
  let activeListings = 0;
  // Event-loop delay shows whether the instance's CPU is saturated.
  const loopDelay = monitorEventLoopDelay({ resolution: 20 });
  loopDelay.enable();
  const refreshes = new Map();
  const validations = new Map();
  const storeLocks = new Map();
  const preferences = {
    allowMachineTranslated: config.allowMachineTranslated,
    allowBilingual: config.allowBilingual,
    preferHearingImpaired: config.preferHearingImpaired
  };

  // Corrections found now are kept for every later request and device; a
  // cached listing (no new downloads) can then still serve corrected files.
  function rememberTimings(context, candidates) {
    for (const candidate of candidates) {
      const transform = timingTransform(candidate, config.syncMinConfidence);
      if (!transform) continue;
      track(timingMemory.rememberAuto(context, { provider: candidate.provider || "opensubtitles", ref: candidate.downloadRef ?? candidate.fileId }, transform));
    }
  }

  function timingAccessAllowed(request, url) {
    const supplied = String(request.headers["x-timing-key"] || url.searchParams.get("key") || "");
    if (config.timingFixKey && supplied) {
      const a = Buffer.from(createHash("sha256").update(supplied).digest("hex"));
      const b = Buffer.from(createHash("sha256").update(config.timingFixKey).digest("hex"));
      if (timingSafeEqual(a, b)) return true;
    }
    // Without a key only the computer running the add-on may use the page.
    return isLoopbackAddress(request.socket.remoteAddress) && !request.headers["x-forwarded-for"];
  }

  function track(promise) {
    const task = promise.catch((error) => logger.warn("background task failed", { reason: error?.message || String(error) }));
    backgroundTasks.add(task);
    task.finally(() => backgroundTasks.delete(task));
    return task;
  }

  async function discoverLocalPlayback() {
    const processSession = await discoverWindowsStremioSession().catch(() => null);
    if (!processSession) return null;
    return await discoverWindowsStremioHlsSession(processSession).catch(() => null) || processSession;
  }

  // Serialises read-merge-write per key so concurrent requests and late
  // provider results never overwrite each other's merges.
  function mergeIntoStore(key, snapshot, media, seedKey) {
    const previousLock = storeLocks.get(key) || Promise.resolve();
    const work = previousLock.then(async () => {
      // A filename-specific entry starts from the same episode's general
      // entry: a background search that failed on the free instance stored
      // an empty list here, which then hid every subtitle of the episode.
      const previous = (await searchStore.get(key)) || (seedKey ? await searchStore.get(seedKey) : undefined);
      const merged = mergeSearchEntries(previous, snapshot, expectedProviders);
      const unresolved = identityUnresolved(media || previous?.media);
      const entry = deepFreeze({ ...merged, complete: merged.complete && !unresolved, media: media || previous?.media });
      // Without a known IMDb identity most providers return nothing; storing
      // that as a result would hide every subtitle for hours.
      if (!unresolved) await searchStore.set(key, entry);
      return entry;
    });
    const settled = work.catch(() => null);
    storeLocks.set(key, settled);
    settled.finally(() => {
      if (storeLocks.get(key) === settled) storeLocks.delete(key);
    });
    return work;
  }

  async function runSearch(key, context, timeoutMs) {
    const onLate = (late) => {
      track(mergeIntoStore(key, late, context.media, context.seedKey).then((entry) => {
        logger.info("late provider results merged", { providers: Object.keys(late.providers), candidates: entry.candidates.length, complete: entry.complete });
        scheduleValidation(key, entry, context);
      }));
    };
    let snapshot;
    if (typeof actualProvider.searchSnapshot === "function") {
      snapshot = await actualProvider.searchSnapshot(context, config.maxSearchPages, timeoutMs, { onLate });
    } else {
      // Custom providers (tests, scripts) implement the plain array API.
      const found = await actualProvider.search(context, config.maxSearchPages, timeoutMs);
      const ids = new Set(["default", ...found.map((candidate) => candidate.provider || "default")]);
      snapshot = deepFreeze({
        candidates: found.map((candidate) => ({ ...candidate })),
        providers: Object.fromEntries([...ids].map((id) => [id, { status: "ok", count: found.filter((candidate) => (candidate.provider || "default") === id).length, at: Date.now() }])),
        complete: true
      });
    }
    return mergeIntoStore(key, snapshot, context.media, context.seedKey);
  }

  const lastRefreshAt = new Map();
  function scheduleRefresh(key, context) {
    if (refreshes.has(key)) return refreshes.get(key);
    // A provider that is down for hours must not trigger a refresh on every
    // single request for the same video.
    if (Date.now() - (lastRefreshAt.get(key) || 0) < 60000) return null;
    lastRefreshAt.set(key, Date.now());
    if (lastRefreshAt.size > 5000) lastRefreshAt.delete(lastRefreshAt.keys().next().value);
    const work = track(runInBackground(() => runSearch(key, context, config.providerHardTimeoutMs)).then((entry) => {
      logger.info("background search refresh finished", { candidates: entry.candidates.length, complete: entry.complete });
      scheduleValidation(key, entry, context);
    }).finally(() => refreshes.delete(key)));
    refreshes.set(key, work);
    return work;
  }

  // Validates candidates that did not fit into the listing deadline. Verdicts
  // are stored, so the next request lists them as verified immediately.
  function scheduleValidation(key, entry, context) {
    if (!config.backgroundValidation || !entry?.candidates?.length || typeof actualProvider.download !== "function") return null;
    if (validations.has(key)) return validations.get(key);
    const work = track(runInBackground(async () => {
      const ranked = rankCandidates(entry.candidates, context, config)
        .filter((candidate) => isSeasonPack(candidate) ? seasonPackForEpisode(candidate, context.media) : candidate.confidence >= Math.max(45, config.minConfidence - 25));
      await deepAnalyzeCandidates(ranked, context, actualProvider, actualCache, {
        limit: Math.min(36, ranked.length),
        timeoutMs: config.backgroundValidationTimeoutMs,
        verdicts: verdictStore,
        preferences,
        loadReference: false,
        syncWithReference: false,
        concurrency: 2,
        shouldPause: () => activeListings > 0,
        maxSeriesSubtitleSeconds: config.maxSeriesSubtitleSeconds
      });
    }).finally(() => validations.delete(key)));
    validations.set(key, work);
    return work;
  }

  // The last episode opened per series (IMDb ids only) moves the warm-up
  // window forward.
  const warmer = { wake: () => {} };
  const watchingNoted = new Map();
  function noteWatching(videoId) {
    const match = String(videoId).match(/^(tt\d{5,10}):(\d{1,4}):(\d{1,5})$/);
    if (!match) return;
    const [, id, season, episode] = match;
    if (watchingNoted.get(id) === videoId) return;
    watchingNoted.set(id, videoId);
    track(choiceStore.get("watching").catch(() => null).then(async (saved) => {
      const series = { ...(saved?.series || {}) };
      series[id] = { season: Number(season), episode: Number(episode), at: Date.now() };
      // Keep the 20 most recent series watched in the last 60 days.
      const kept = Object.entries(series)
        .filter(([, value]) => Date.now() - value.at < 60 * 86400000)
        .sort((a, b) => b[1].at - a[1].at)
        .slice(0, 20);
      await choiceStore.set("watching", { series: Object.fromEntries(kept) });
      warmer.wake();
    }));
  }

  // "Style" of a subtitle: the Arabic team, or else the release group
  // written in its file name ("[Mugi] Show - 01.ass" -> mugi).
  function subtitleStyle(item) {
    const team = arabicFansubTeam({ fileName: item.fileName, release: item.release, provider: item.provider });
    if (team) return `team:${String(team).toLowerCase()}`;
    const name = String(item.fileName || item.release || "");
    const bracket = name.match(/^\s*\[([^\]]{2,30})\]/)?.[1];
    const group = bracket || parseReleaseName(name).group;
    return group ? `${item.provider || "opensubtitles"}:group:${String(group).toLowerCase()}` : "";
  }
  function mediaKeyId(media) {
    return media?.imdbId ? `tt${String(media.imdbId).replace(/^tt/, "")}` : String(media?.sourceId || "");
  }
  function episodeChoiceKey(media) {
    const id = mediaKeyId(media);
    if (!id) return "";
    return media.type === "series" ? `ep:${id}:${media.season}:${media.episode}` : `movie:${id}`;
  }
  function seriesChoiceKey(media) {
    const id = mediaKeyId(media);
    return media?.type === "series" && id ? `series:${id}` : "";
  }
  // Called when Stremio loads a listed subtitle: the first token item is
  // the entry the viewer picked (the others are fallbacks).
  function rememberChoice(payload) {
    const media = payload?.context?.media;
    const first = payload?.items?.[0];
    if (!media || !first) return;
    const at = Date.now();
    const episodeKey = episodeChoiceKey(media);
    const seriesKey = seriesChoiceKey(media);
    const style = subtitleStyle(first);
    track(Promise.all([
      episodeKey ? choiceStore.set(episodeKey, { id: itemId(first), at }) : null,
      seriesKey && style ? choiceStore.set(seriesKey, { style, at }) : null
    ]).then(() => {
      // Prepared answers are rebuilt with the new order.
      stateEpoch += 1;
    }));
  }
  async function loadChoices(media) {
    const episodeKey = episodeChoiceKey(media);
    const seriesKey = seriesChoiceKey(media);
    const [episode, series] = await Promise.all([
      episodeKey ? choiceStore.get(episodeKey).catch(() => null) : null,
      seriesKey ? choiceStore.get(seriesKey).catch(() => null) : null
    ]);
    return { episode: episode?.id || "", style: series?.style || "" };
  }

  // While an episode is watched, search the next one in the background so its
  // list is ready (and instant) when the player asks for it.
  const prefetched = new Map();
  // The next two episodes are searched (and then verified) in the
  // background, spaced out so the small instance is not flooded. A list that
  // is already complete is left alone; a partial one is completed.
  function prefetchNextEpisode(type, videoId) {
    const match = String(videoId).match(/^(.*:)(\d{1,5})$/);
    if (!match) return;
    [1, 2].forEach((step, index) => {
      const nextId = `${match[1]}${Number(match[2]) + step}`;
      if (prefetched.has(nextId)) return;
      prefetched.set(nextId, Date.now());
      if (prefetched.size > 2000) prefetched.delete(prefetched.keys().next().value);
      const timer = setTimeout(() => {
        retryTimers.delete(timer);
        track(runInBackground(async () => {
          const nextKey = searchKey(type, nextId, {});
          const existing = await searchStore.get(nextKey);
          if (existing && existing.complete && !identityUnresolved(existing.media)) return;
          const nextMedia = await alignMediaToFilename(await resolveVideoId(type, nextId), {});
          if (identityUnresolved(nextMedia)) return;
          scheduleRefresh(nextKey, { media: nextMedia, extra: { filename: "", videoHash: "" } });
        }));
      }, index === 0 ? 3000 : 45000);
      timer.unref?.();
      retryTimers.add(timer);
    });
  }

  // Load large provider indexes (archive listings, show lists) at start-up
  // instead of inside the first listing, where parsing them on a small
  // instance delayed every other provider.
  setTimeout(() => {
    actualProvider.warm?.().catch(() => null);
  }, 1000).unref?.();

  // Warm local playback discovery outside subtitle-list requests. On Windows,
  // process discovery may take several seconds and must never make TV/mobile
  // clients abandon the first subtitle list.
  setImmediate(() => {
    discoverLocalPlayback().then((discovered) => {
      if (discovered) companion.registerTrusted(discovered);
    }).catch(() => null);
  });

  // The whole listing computation for one request. Kept separate from the
  // HTTP handler so a finished answer can be rebuilt in the background.
  async function buildListing(request, type, encodedId, encodedExtra, srtOnly, started, requestId, debug = false) {
    const listingDeadline = started + config.listingDeadlineMs;
    const videoId = decodeURIComponent(encodedId);
    if (videoId.length > 200) throw new Error("Video id is too long");
    const extra = parseExtra(decodeURIComponent(encodedExtra));
    const key = searchKey(type, videoId, extra);
    const marks = [];
    const mark = (name) => marks.push(`${name}:${Date.now() - started}`);
    let entry = await searchStore.get(key);
    mark("get");
    // Entries saved by older versions for a Kitsu id that was never mapped
    // to IMDb are empty by construction; ignore them and resolve again.
    if (entry && identityUnresolved(entry.media)) entry = undefined;
    // A request with a filename/hash has its own cache entry, but the same
    // episode searched without them (or prepared in advance as "next
    // episode") already holds almost every candidate: answer from it now
    // and complete the filename-specific search in the background.
    let seeded = false;
    const seedKey = extra.filename || extra.videoHash ? searchKey(type, videoId, {}) : undefined;
    if (seedKey && !entry?.candidates?.length) {
      const base = await searchStore.get(seedKey);
      if (base && !identityUnresolved(base.media) && base.candidates.length > (entry?.candidates?.length || 0)) {
        entry = base;
        seeded = true;
      }
    }
    // Reuse the media identity resolved the first time. Re-resolving on
    // every request made results depend on transient Cinemeta timeouts.
    // A seeded answer uses the episode's stored identity plus what the
    // filename itself says; the Cinemeta checks (several seconds on the
    // free instance) run with the background refresh instead.
    let media = seeded ? alignMediaLocally(entry.media, extra) : entry?.media;
    if (!media) {
      const resolvedMedia = await resolveVideoId(type, videoId);
      media = await alignMediaToFilename(resolvedMedia, extra);
    }
    mark("media");
    const context = { media, extra, seedKey };
    const cacheState = !entry ? "miss" : seeded ? "seeded" : entry.complete && Date.now() - entry.updatedAt < freshForMs(entry, config) ? "fresh" : "stale";
    if (!entry) {
      // First request for this video: finding candidates matters more
      // than verifying them now (verification continues in the background
      // and every link has download fallbacks). On a slow free instance a
      // 5 s search budget returned only a handful of candidates.
      const searchBudget = Math.max(500, Math.max(config.providerSearchTimeoutMs, listingDeadline - Date.now() - 1800));
      entry = await runSearch(key, context, searchBudget);
      if (!entry.complete) scheduleRefreshLater(key, context);
    } else if (cacheState === "seeded") {
      track(runInBackground(async () => {
        const aligned = await alignMediaToFilename(await resolveVideoId(type, videoId), extra);
        await scheduleRefresh(key, { media: aligned, extra, seedKey });
      }).catch(() => null));
    } else if (cacheState === "stale") {
      // Serve the best previous result now and refresh in the background.
      scheduleRefresh(key, context);
    }
    const candidates = entry.candidates;
    logger.info("subtitle listing search ready", { requestId, candidates: candidates.length, cache: cacheState, complete: entry.complete, elapsedMs: Date.now() - started });
    mark("search");
    let ranked = rankCandidates(candidates, context, config);
    const rankedAll = ranked;
    mark("rank");
    const fallbackConfidence = Math.max(45, config.minConfidence - 25);
    const preliminary = ranked.filter((candidate) =>
      isSeasonPack(candidate) ? seasonPackForEpisode(candidate, media) : candidate.confidence >= fallbackConfidence
    );
    const companionBudget = Math.max(0, Math.min(config.companionWaitMs, listingDeadline - Date.now() - 1000));
    let companionSession = companionBudget > 0 ? await companion.waitForRecent(companionBudget) : companion.latest();
    if (!companionSession && process.platform === "win32") {
      const discoveryBudget = Math.max(0, Math.min(750, listingDeadline - Date.now() - 1000));
      const discovered = discoveryBudget > 0
        ? await within(discoverLocalPlayback(), discoveryBudget, null)
        : null;
      if (discovered) companionSession = companion.registerTrusted(discovered);
    }
    const referenceBudget = Math.max(0, Math.min(1800, listingDeadline - Date.now() - 1000));
    const localReference = companionSession && referenceBudget > 0
      ? await within(
        mediaAnalyzer.bestReference(companionSession.streamUrl, companionSession.duration, companionSession.playbackTime).catch(() => null),
        referenceBudget,
        null
      )
      : null;
    const analysisBudget = Math.max(0, Math.min(config.deepAnalysisTimeoutMs, listingDeadline - Date.now() - 300));
    if (analysisBudget >= 500) {
      ranked = await deepAnalyzeCandidates(preliminary, context, actualProvider, actualCache, {
        limit: config.deepAnalysisCandidates,
        // New downloads inside the request; the rest are validated in the
        // background and reused from the verdict store next time.
        // Only a brand-new search parses files while the player waits;
        // a cached, stale or seeded list answers at once and anything
        // still unverified is checked by the background validation.
        maxDownloads: cacheState === "miss" ? config.listingDownloads : 0,
        // Reading earlier verdicts is network I/O; a cached list does not
        // wait long for them (the rest are listed as not yet verified).
        timeoutMs: cacheState === "miss" ? analysisBudget : Math.min(analysisBudget, 1500),
        reference: localReference,
        verdicts: verdictStore,
        preferences,
        expectedDurationSeconds: companionSession?.duration,
        maxSeriesSubtitleSeconds: config.maxSeriesSubtitleSeconds
      });
    } else {
      ranked = preliminary;
    }
    mark("deep");
    rememberTimings(context, ranked);
    if (ranked.some((candidate) => !candidate.deepAnalyzed)) scheduleValidation(key, entry, context);
    const requireVerifiedDownload = config.validateBeforeListing && typeof actualProvider.download === "function";
    // A provider whose daily download quota is used up cannot deliver
    // its files; listing them only produces "Failed to load" in Stremio.
    const unavailable = (candidate) => Boolean(actualProvider.byId?.get(candidate.provider)?.isQuotaExhausted?.());
    // A season pack is listed only after its archive was opened and the
    // requested episode was found inside it.
    const usable = dropDuplicatesAndOutliers(ranked.filter((candidate) => candidate.confidence >= 5 && !candidate.downloadFailed && !unavailable(candidate) &&
      (!isSeasonPack(candidate) || candidate.deepAnalyzed === true)), companionSession?.duration);
    let eligible = requireVerifiedDownload
      ? [
        ...usable.filter((candidate) => candidate.deepAnalyzed === true && candidate.confidence >= verifiedThreshold(candidate) && !candidate.reasons?.includes("timing-mismatch")),
        ...usable.filter((candidate) => candidate.deepAnalyzed !== true && candidate.confidence >= config.minConfidence && !candidate.reasons?.includes("timing-mismatch"))
      ]
      : [
        ...usable.filter((candidate) => candidate.confidence >= config.minConfidence),
        ...usable.filter((candidate) => candidate.confidence < config.minConfidence)
      ];
    // SRT mode: the same subtitles, converted on delivery to SRT that keeps
    // colours, italics/bold and top/bottom position (<font color>, {anN}),
    // which Android TV and iPad players render with correct timing.
    if (srtOnly) eligible = eligible.map((candidate) => ({ ...candidate, actualFormat: "srt" }));
    const noChoice = { episode: "", style: "" };
    const [ratings, choices] = await Promise.all([
      within(timingMemory.ratings(context), 800, {}).catch(() => ({})),
      within(loadChoices(media), 800, noChoice).catch(() => noChoice)
    ]);
    eligible = eligible.map((candidate) => {
      const id = itemId({ provider: candidate.provider || "opensubtitles", ref: candidate.downloadRef ?? candidate.fileId });
      const rating = ratings[id];
      const timingCorrected = Boolean(timingTransform(candidate, config.syncMinConfidence));
      // 📌 the file picked for this episode before; then files by the team or
      // group the viewer picked last in this series.
      const chosen = choices.episode && choices.episode === id ? 2 : choices.style && choices.style === subtitleStyle(candidate) ? 1 : 0;
      return rating || timingCorrected || chosen ? { ...candidate, userRating: rating || 0, timingCorrected, chosen } : candidate;
    });
    const displayRanked = dropSameFiles(sortForDisplay(eligible));
    const diverse = config.resultMode === "best" ? displayRanked.slice(0, 1) : selectDiverseCandidates(displayRanked, config.maxResults);
    const selected = sortForDisplay(diverse);
    const subtitles = selected.map((candidate, index) => {
      const extension = extensionOf(candidate);
      const fallback = fallbackCandidates(eligible, candidate, extension, config.downloadFallbacks);
      const items = fallback.map((item) => ({
        provider: item.provider || "opensubtitles",
        ref: item.downloadRef ?? item.fileId,
        fileId: item.fileId,
        season: item.featureDetails?.seasonNumber ?? parseReleaseName(item.fileName || item.release || "").season ?? media.season,
        episode: item.featureDetails?.episodeNumber ?? parseReleaseName(item.fileName || item.release || "").episode ?? media.episode,
        fileName: item.fileName || item.release || `subtitle.${extensionOf(item)}`,
        extension: extensionOf(item),
        fps: item.fps,
        confidence: item.confidence,
        reasons: (item.reasons || []).filter((reason) => !reason.startsWith("q:")),
        ...(strictSeasonPack(item) ? { strictPack: true } : {}),
        syncScore: item.syncScore || 0,
        qualityScore: item.qualityScore || 0,
        verified: Boolean(item.deepAnalyzed),
        transform: serializableTransform(timingTransform(item, config.syncMinConfidence))
      }));
      const token = signSubtitleToken({ items, extension, context: { media, extra } }, config.tokenSecret);
      const stableId = createHash("sha256").update(`${candidate.provider || "opensubtitles"}:${candidate.fileId}`).digest("hex").slice(0, 16);
      const label = detailedResultLabel(candidate, index);
      return {
        id: `arabic-syncrank-${stableId}`,
        // Some players (Harbor) ignore "label" and title the subtitle with
        // the last part of its URL, so the readable label goes there too.
        url: `${baseUrl(request, config)}/subtitle/${token}/${readableUrlName(label)}.${extension}`,
        lang: "ara",
        label
      };
    });
    mark("build");
    logger.info("subtitle search completed", {
      requestId,
      mediaId: media.id,
      filename: extra.filename ? path.basename(extra.filename).slice(0, 160) : "",
      hasVideoHash: Boolean(extra.videoHash),
      count: subtitles.length,
      providerCandidates: candidates.length,
      providers: Object.fromEntries(Object.entries(entry.providers || {}).map(([id, status]) => [id, `${status.status}:${status.count ?? 0}`])),
      eligibleCandidates: eligible.length,
      deepAnalyzed: selected.filter((candidate) => candidate.deepAnalyzed).length,
      timingCalibrated: selected.filter((candidate) => timingTransform(candidate, config.syncMinConfidence)).length,
      styledCandidates: selected.filter((candidate) => candidate.styled).length,
      companionReference: localReference?.source,
      cache: cacheState,
      complete: entry.complete,
      durationMs: Date.now() - started
    });
    // A short client cache only for complete results; partial lists must
    // be re-requested so the improved list shows up on the next open.
    const cacheMaxAge = entry.complete ? 300 : 0;
    // Counts only (no ids, keys or names): lets the owner see why a list
    // is short without access to the hosting logs.
    // Per-source counts and season-pack progress (no names or ids), so a short
    // list can be explained from the response header alone.
    const sources = Object.entries(entry.providers || {})
      .map(([id, item]) => `${id}:${item.status}:${item.count ?? 0}${item.reason ? `:${String(item.reason).replace(/^.*?(?:failed|error)\s*(?:with)?\s*/i, "").replace(/[^\w .-]/g, " ").slice(0, 40)}` : ""}`)
      .join(",");
    const packs = rankedAll.filter(isSeasonPack);
    const packIds = new Set(packs.map((candidate) => `${candidate.provider}:${candidate.fileId}`));
    const packStatus = `${packs.length}/${packs.filter((candidate) => seasonPackForEpisode(candidate, media)).length}/` +
      `${ranked.filter((candidate) => packIds.has(`${candidate.provider}:${candidate.fileId}`) && candidate.deepAnalyzed).length}/` +
      `${eligible.filter((candidate) => packIds.has(`${candidate.provider}:${candidate.fileId}`)).length}`;
    const status = `ok;src=${sources};packs=${packStatus};candidates=${candidates.length};ranked=${ranked.length};eligible=${eligible.length};verified=${selected.filter((candidate) => candidate.deepAnalyzed).length};cache=${cacheState};complete=${entry.complete};ms=${Date.now() - started};lag=${Math.round(loopDelay.max / 1e6)};t=${marks.join(",")}`;
    if (media.type === "series") {
      prefetchNextEpisode(type, videoId);
      noteWatching(videoId);
    }
    let debugRows;
    if (debug) {
      // "?debug=1": what happened to every candidate (owner diagnostics).
      const id = (candidate) => `${candidate.provider}:${candidate.fileId}`;
      const preliminaryIds = new Set(preliminary.map(id));
      const analyzed = new Map(ranked.map((candidate) => [id(candidate), candidate]));
      const eligibleIds = new Set(eligible.map(id));
      const listedIds = new Set(selected.map(id));
      debugRows = await Promise.all(rankedAll.map(async (candidate) => {
        let stage;
        const after = analyzed.get(id(candidate));
        if (listedIds.has(id(candidate))) stage = "listed";
        else if (!preliminaryIds.has(id(candidate))) stage = isSeasonPack(candidate) ? "pack-not-this-season" : "low-confidence";
        else if (!after) {
          const verdict = await verdictStore.get(verdictKey(candidate, context)).catch(() => undefined);
          stage = verdict && !verdict.ok ? `rejected:${verdict.reason}` : verdict?.ok ? "duplicate-content" : "dropped";
        } else if (after.downloadFailed) stage = "download-failed";
        else if (after.validationPending) stage = "pending";
        else if (!eligibleIds.has(id(candidate))) stage = `not-eligible:conf=${after.confidence}${after.reasons?.includes("timing-mismatch") ? ",timing-mismatch" : ""}`;
        else stage = "over-limit";
        return {
          provider: candidate.provider,
          file: String(candidate.fileName || candidate.release || "").slice(0, 90),
          confidence: after?.confidence ?? candidate.confidence,
          reasons: (after?.reasons || candidate.reasons || []).filter((reason) => !reason.startsWith("q:")).join(","),
          stage
        };
      }));
    }
    return { key, complete: entry.complete, count: subtitles.length, body: { subtitles, cacheMaxAge, ...(debugRows ? { debug: debugRows } : {}) }, headers: { "Cache-Control": "no-store", "X-Listing-Status": status } };
  }

  // Finished answers per URL. A player asking again (Harbor asks on every
  // open) gets the last answer in milliseconds instead of waiting seconds
  // for ranking on a fraction of a CPU; when anything changed since (new
  // search results or verdicts) the answer is rebuilt in the background.
  const readyAnswers = new Map();
  const answerRebuilds = new Set();
  let stateEpoch = 0;
  const answersBySearchKey = new Map();
  for (const store of [searchStore, verdictStore]) {
    const set = store.set.bind(store);
    store.set = (...args) => {
      stateEpoch += 1;
      const stored = set(...args);
      // New search results: prepare the answer now, before the next open.
      if (store === searchStore) {
        for (const answerKey of answersBySearchKey.get(args[0]) || []) {
          const ready = readyAnswers.get(answerKey);
          if (ready) rebuildAnswer(answerKey, ready.build);
        }
      }
      return stored;
    };
  }
  function rememberAnswer(answerKey, result, epoch, build) {
    readyAnswers.delete(answerKey);
    if (!result.count) return;
    readyAnswers.set(answerKey, { ...result, epoch, build, at: Date.now() });
    if (!answersBySearchKey.has(result.key)) answersBySearchKey.set(result.key, new Set());
    answersBySearchKey.get(result.key).add(answerKey);
    while (readyAnswers.size > 1000) {
      const oldest = readyAnswers.keys().next().value;
      answersBySearchKey.get(readyAnswers.get(oldest).key)?.delete(oldest);
      readyAnswers.delete(oldest);
    }
    while (answersBySearchKey.size > 2000) answersBySearchKey.delete(answersBySearchKey.keys().next().value);
  }
  function rebuildAnswer(answerKey, build) {
    if (answerRebuilds.has(answerKey)) return;
    answerRebuilds.add(answerKey);
    track(runInBackground(async () => {
      const epoch = stateEpoch;
      rememberAnswer(answerKey, await build(), epoch, build);
    }).finally(() => answerRebuilds.delete(answerKey)));
  }

  const server = http.createServer(async (request, response) => {
    const requestId = randomUUID();
    const started = Date.now();
    let url;
    try {
      url = new URL(request.url, "http://localhost");
      // "/srt/..." is the same add-on with every subtitle delivered as SRT.
      // Android TV / iPad players time ASS files differently from desktop
      // (subtitles appeared after the speech on a Mi Box while SRT was exact).
      let srtOnly = false;
      if (url.pathname === "/srt" || url.pathname.startsWith("/srt/")) {
        srtOnly = true;
        url.pathname = url.pathname.slice(4) || "/";
      }
      if (url.pathname.startsWith("/subtitles/") || url.pathname.startsWith("/subtitle/")) {
        activeListings += 1;
        if (activeListings === 1) loopDelay.reset();
        let released = false;
        const release = () => {
          if (!released) {
            released = true;
            activeListings -= 1;
          }
        };
        response.once("finish", release);
        response.once("close", release);
      }
      const companionRoute = url.pathname.startsWith("/companion/");
      if (request.method === "OPTIONS") {
        if (companionRoute) {
          const origin = request.headers.origin;
          if (!isLoopbackAddress(request.socket.remoteAddress) || !isAllowedCompanionOrigin(origin)) {
            response.writeHead(403, SECURITY_HEADERS);
            return response.end();
          }
          response.writeHead(204, { ...(origin ? { "Access-Control-Allow-Origin": origin, Vary: "Origin" } : {}), "Access-Control-Allow-Methods": "GET, POST", "Access-Control-Allow-Headers": "Content-Type", ...SECURITY_HEADERS });
          return response.end();
        }
        response.writeHead(204, { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Methods": "GET, OPTIONS", "Access-Control-Allow-Headers": "Content-Type", ...SECURITY_HEADERS });
        return response.end();
      }
      if (companionRoute) {
        const origin = request.headers.origin;
        if (!isLoopbackAddress(request.socket.remoteAddress) || !isAllowedCompanionOrigin(origin)) return json(response, 403, { error: "Local companion only" }, { "Access-Control-Allow-Origin": undefined });
        // Never "*" on companion routes: only the calling Stremio origin.
        const corsHeaders = origin ? { "Access-Control-Allow-Origin": origin, Vary: "Origin" } : { "Access-Control-Allow-Origin": undefined };
        if (url.pathname === "/companion/session" && request.method === "POST") {
          const session = companion.register(await readJsonBody(request));
          mediaAnalyzer.bestReference(session.streamUrl, session.duration, session.playbackTime).catch(() => null);
          return json(response, 200, { ok: true, receivedAt: session.receivedAt }, corsHeaders);
        }
        if (url.pathname === "/companion/status" && request.method === "GET") {
          let session = companion.latest();
          if (!session) {
            const discovered = await discoverLocalPlayback();
            if (discovered) session = companion.registerTrusted(discovered);
          }
          return json(response, 200, {
            connected: Boolean(session),
            ageMs: session ? Date.now() - session.receivedAt : null,
            duration: session?.duration,
            title: session?.title,
            discoveredFrom: session?.discoveredFrom
          }, corsHeaders);
        }
        return json(response, 404, { error: "Not found" }, corsHeaders);
      }
      if (url.pathname === "/timing" || url.pathname.startsWith("/timing/")) {
        if (url.pathname === "/timing" && request.method === "GET") {
          const page = await readFile(path.join(moduleDirectory, "../public/timing.html"), "utf8");
          response.writeHead(200, {
            "Content-Type": "text/html; charset=utf-8",
            ...SECURITY_HEADERS,
            "Cache-Control": "no-store",
            "Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; connect-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'"
          });
          return response.end(page);
        }
        if (!timingAccessAllowed(request, url)) return json(response, 403, { error: "Timing key required" }, { "Access-Control-Allow-Origin": undefined, "Cache-Control": "no-store" });
        if (url.pathname === "/timing/recent" && request.method === "GET") {
          return json(response, 200, { recent: await timingMemory.recent() }, { "Access-Control-Allow-Origin": undefined, "Cache-Control": "no-store" });
        }
        if (url.pathname === "/timing/rate" && request.method === "POST") {
          const body = await readJsonBody(request, 2048);
          const result = await timingMemory.rate(String(body.key || ""), String(body.item || ""), Number(body.rating));
          return json(response, 200, { ok: true, ...result }, { "Access-Control-Allow-Origin": undefined, "Cache-Control": "no-store" });
        }
        if (url.pathname === "/timing/fix" && request.method === "POST") {
          const body = await readJsonBody(request, 2048);
          const seconds = Number(body.seconds);
          if (!body.reset && (!Number.isFinite(seconds) || Math.abs(seconds) > 600)) return json(response, 400, { error: "seconds must be between -600 and 600" }, { "Access-Control-Allow-Origin": undefined });
          const result = await timingMemory.fix(String(body.key || ""), String(body.item || ""), { seconds, reset: Boolean(body.reset) });
          logger.info("timing corrected by user", { seconds: body.reset ? "reset" : seconds });
          return json(response, 200, { ok: true, ...result }, { "Access-Control-Allow-Origin": undefined, "Cache-Control": "no-store" });
        }
        return json(response, 404, { error: "Not found" }, { "Access-Control-Allow-Origin": undefined });
      }
      if (request.method !== "GET" && request.method !== "HEAD") return json(response, 405, { error: "Method not allowed" });
      if (url.pathname === "/health") {
        return json(response, 200, {
          ok: true,
          version: manifest.version,
          providerConfigured: configuredProviders.length > 0 || Boolean(provider),
          providers: actualProvider.names || ["custom"],
          persistentCache: remote ? "upstash" : "disk",
          ...(server.warmState ? { warmUp: server.warmState } : {})
        });
      }
      if (url.pathname === "/manifest.json") {
        warmer.wake();
        return json(response, 200, srtOnly ? srtManifest : manifest);
      }
      if (url.pathname === "/" || url.pathname === "/configure") {
        const template = await readFile(path.join(moduleDirectory, "../public/configure.html"), "utf8").catch(() => embeddedConfigurePage);
        const manifestUrl = `${baseUrl(request, config)}/manifest.json`;
        const srtManifestUrl = `${baseUrl(request, config)}/srt/manifest.json`;
        return html(response, 200, template
          .replaceAll("{{SRT_MANIFEST_URL}}", escapeHtml(srtManifestUrl))
          .replaceAll("{{SRT_STREMIO_URL}}", escapeHtml(srtManifestUrl.replace(/^https?:/, "stremio:")))
          .replaceAll("{{MANIFEST_URL}}", escapeHtml(manifestUrl))
          .replaceAll("{{STREMIO_URL}}", escapeHtml(manifestUrl.replace(/^https?:/, "stremio:")))
          .replaceAll("{{VERSION}}", escapeHtml(manifest.version)));
      }

      const subtitleRoute = url.pathname.match(/^\/subtitles\/(movie|series)\/([^/]+)(?:\/(.*))?\.json$/);
      if (subtitleRoute) {
        const [, type, encodedId, encodedExtra = ""] = subtitleRoute;
        const answerKey = `${srtOnly ? "srt" : "all"}|${baseUrl(request, config)}|${url.pathname}`;
        const debug = url.searchParams.get("debug") === "1";
        const ready = config.readyAnswers && !companion.latest() && !debug ? readyAnswers.get(answerKey) : undefined;
        if (ready && Date.now() - ready.at < 6 * 3600 * 1000) {
          if (ready.epoch !== stateEpoch || !ready.complete) rebuildAnswer(answerKey, ready.build);
          return json(response, 200, ready.body, { ...ready.headers, "X-Listing-Status": `${ready.headers["X-Listing-Status"]};answer=ready;served=${Date.now() - started}` });
        }
        const epoch = stateEpoch;
        const result = await buildListing(request, type, encodedId, encodedExtra, srtOnly, started, requestId, debug);
        if (debug) return json(response, 200, result.body, result.headers);
        // Rebuilds keep only what a URL needs, not the original request.
        const headers = { host: request.headers.host, "x-forwarded-proto": request.headers["x-forwarded-proto"] };
        rememberAnswer(answerKey, result, epoch, () => buildListing({ headers }, type, encodedId, encodedExtra, srtOnly, Date.now(), randomUUID()));
        return json(response, 200, result.body, result.headers);
      }

      // "/subtitle/<token>.<ext>" (older links) or "/subtitle/<token>/<name>.<ext>".
      const proxyRoute = url.pathname.match(/^\/subtitle\/([A-Za-z0-9_.-]{1,12000}?)(?:\/[^/]{1,800})?\.(srt|vtt|ass|ssa)$/i);
      if (proxyRoute) {
        const payload = verifySubtitleToken(proxyRoute[1], config.tokenSecret);
        if (payload.extension !== proxyRoute[2].toLowerCase()) throw new Error("Subtitle extension mismatch");
        let lastError;
        const tokenItems = payload.items || (payload.fileIds || []).map((ref) => ({ provider: "opensubtitles", ref }));
        if (request.method === "GET") rememberChoice(payload);
        for (const item of tokenItems.slice(0, 8)) {
          try {
            const tokenContext = payload.context || { media: { season: item.season, episode: item.episode, type: item.episode != null ? "series" : "movie" }, extra: {} };
            const remembered = await verdictStore.get(verdictKey({ provider: item.provider, downloadRef: item.ref }, tokenContext)).catch(() => undefined);
            if (remembered && remembered.ok === false && !retryableRejection(remembered)) throw new Error(`Previously rejected: ${remembered.reason}`);
            const key = normalizedSubtitleCacheKey({
              provider: item.provider,
              ref: item.ref,
              season: item.season,
              episode: item.episode
            });
            let normalizedBuffer = await actualCache.getFile(key);
            let extension = item.extension || payload.extension;
            if (!normalizedBuffer) {
              const downloaded = await actualProvider.download(item);
              const normalized = normalizeSubtitle(downloaded.buffer, {
                season: item.season,
                episode: item.episode,
                fileName: downloaded.fileName || item.fileName,
                outputExtension: payload.extension,
                fps: item.fps,
                preserveFormat: false,
                allowFormatMismatch: true,
                requireEpisodeEntry: item.strictPack === true
              });
              if (item.episode != null && normalized.analysis.durationSeconds > config.maxSeriesSubtitleSeconds) {
                throw new Error(`Series subtitle duration is implausible (${Math.round(normalized.analysis.durationSeconds / 60)} minutes)`);
              }
              if (!remembered?.ok) {
                const assessment = assessSubtitle(normalized.buffer.toString("utf8"), {
                  fileName: item.fileName,
                  allowMachineTranslated: config.allowMachineTranslated,
                  allowBilingual: config.allowBilingual
                });
                if (!assessment.accepted && assessment.verdict !== "broken") throw new Error(`Subtitle rejected: ${assessment.verdict}`);
                if (assessment.verdict === "broken" && normalized.analysis.cueCount < 1) throw new Error("Subtitle has no cues");
              }
              normalizedBuffer = normalized.buffer;
              extension = normalized.extension;
              await actualCache.setFile(key, normalizedBuffer);
              logger.info("subtitle normalized", { requestId, provider: item.provider, encoding: normalized.encoding, cueCount: normalized.analysis.cueCount });
            } else {
              // Cached files keep their real format; read it from the content.
              extension = detectTextFormat(normalizedBuffer.subarray(0, 4096).toString("utf8"));
            }
            // The URL promised payload.extension. A fallback (or a cached
            // file) in another format must be converted, or Stremio rejects
            // it with "Failed to load external subtitles".
            if (extension !== payload.extension) {
              const converted = convertToFormat(normalizedBuffer, payload.extension);
              normalizedBuffer = converted.buffer;
              extension = converted.extension;
            }
            let transform = item.transform;
            const savedTiming = payload.context ? await within(timingMemory.lookup(payload.context, item), 1500, {}).catch(() => ({})) : {};
            if (!transform && savedTiming.auto) transform = savedTiming.auto;
            if (!transform && payload.context && !item.reasons?.includes("exact-hash")) {
              let session = companion.latest();
              if (!session && process.platform === "win32") {
                const discovered = await within(discoverLocalPlayback(), 1000, null);
                if (discovered) session = companion.registerTrusted(discovered);
              }
              if (session) {
                const candidate = {
                  provider: item.provider,
                  fileId: item.fileId ?? item.ref,
                  downloadRef: item.ref,
                  fileName: item.fileName,
                  confidence: item.confidence || 45,
                  reasons: item.reasons || [],
                  syncScore: item.syncScore || 0,
                  qualityScore: item.qualityScore || 0
                };
                const onDemandDeadline = Date.now() + config.onDemandSyncTimeoutMs;
                const reference = await within(
                  mediaAnalyzer.bestReference(session.streamUrl, session.duration, session.playbackTime).catch(() => null),
                  Math.max(250, Math.min(2500, onDemandDeadline - Date.now() - 500)),
                  null
                );
                if (reference) {
                  const analyzed = await deepAnalyzeCandidates([candidate], payload.context, actualProvider, actualCache, {
                    limit: 1,
                    timeoutMs: Math.max(1000, onDemandDeadline - Date.now()),
                    reference,
                    verdicts: verdictStore,
                    preferences
                  }).catch(() => [candidate]);
                  transform = timingTransform(analyzed[0], config.syncMinConfidence);
                  if (transform) track(timingMemory.rememberAuto(payload.context, item, transform));
                }
              }
            }
            // A correction typed in on the /timing page wins over everything.
            if (savedTiming.manual) transform = savedTiming.manual;
            if (payload.context) {
              const label = (() => {
                try { return decodeURIComponent(url.pathname.split("/").slice(3).join("/").replace(/\.(srt|vtt|ass|ssa)$/i, "")); } catch { return ""; }
              })();
              track(timingMemory.recordServed(payload.context, item, transform, label.replace(/[-_]+/g, " ")));
            }
            if (transform && !isIdentityTransform(transform)) {
              normalizedBuffer = Buffer.from(retimeSubtitle(normalizedBuffer.toString("utf8"), extension, transform), "utf8");
              logger.info("subtitle retimed", {
                requestId,
                provider: item.provider,
                score: Number(transform.score).toFixed(3),
                model: transform.segments ? `piecewise:${transform.segments.length}` : "linear",
                scale: transform.segments ? undefined : Number(transform.scale).toFixed(6),
                offset: transform.segments ? undefined : Number(transform.offset).toFixed(3),
                reference: transform.reference
              });
            }
            if (config.polishSubtitles) {
              normalizedBuffer = Buffer.from(polishSubtitle(normalizedBuffer.toString("utf8"), extension), "utf8");
            }
            const contentType = extension === "vtt" ? "text/vtt" : extension === "ass" || extension === "ssa" ? "text/x-ssa" : "application/x-subrip";
            response.writeHead(200, { "Content-Type": `${contentType}; charset=utf-8`, "Access-Control-Allow-Origin": "*", "Cache-Control": "public, max-age=300", ...SECURITY_HEADERS });
            return response.end(request.method === "HEAD" ? undefined : normalizedBuffer);
          } catch (error) {
            lastError = error;
            if (!isTransientError(error) && !/Previously rejected/.test(error.message) && payload.context) {
              await verdictStore.set(verdictKey({ provider: item.provider, downloadRef: item.ref }, payload.context), { ok: false, reason: String(error.message).slice(0, 160) }).catch(() => null);
            }
            logger.warn("subtitle candidate rejected", { requestId, provider: item.provider, reason: error.message });
          }
        }
        throw lastError || new Error("No usable subtitle candidate");
      }

      return json(response, 404, { error: "Not found" });
    } catch (error) {
      logger.error("request failed", { requestId, reason: error.message, durationMs: Date.now() - started });
      // Stremio Desktop 4's bundled Node 18 server can crash when a proxied
      // subtitle URL returns JSON. Always answer subtitle-file routes with a
      // subtitle payload, even after every upstream fallback has failed.
      const subtitleExtension = url?.pathname.match(/^\/subtitle\/.*\.(srt|vtt|ass|ssa)$/i)?.[1]?.toLowerCase();
      if (subtitleExtension) {
        const fallback = emptySubtitle(subtitleExtension);
        response.writeHead(200, {
          "Content-Type": fallback.contentType,
          "Access-Control-Allow-Origin": "*",
          "Cache-Control": "no-store",
          "X-Subtitle-Fallback": "empty",
          ...SECURITY_HEADERS
        });
        return response.end(fallback.body);
      }
      if (/^\/subtitles\//.test(url?.pathname || "")) {
        // Never answer a listing with an error page; an empty list lets
        // Stremio retry later instead of showing a failure.
        const reason = String(error?.message || "error").replace(/[^\w .:-]/g, " ").slice(0, 120);
        return json(response, 200, { subtitles: [], cacheMaxAge: 0 }, { "Cache-Control": "no-store", "X-Listing-Status": `error;${reason};ms=${Date.now() - started}` });
      }
      const safeMessage = /token|extension|too long|too large|Only IMDb|Unknown subtitle/i.test(error.message) ? error.message : "Request failed";
      return json(response, /missing|quota/i.test(error.message) ? 503 : 400, { error: safeMessage, requestId });
    }
  });

  const retryTimers = new Set();
  function scheduleRefreshLater(key, context) {
    // A partial first search (provider timed out) is refreshed shortly after,
    // independent of the late-result merge, so the next open is complete.
    const timer = setTimeout(() => {
      retryTimers.delete(timer);
      scheduleRefresh(key, context);
    }, 15000);
    timer.unref?.();
    retryTimers.add(timer);
  }

  // Background preparation (WARM_SERIES plus every series being watched):
  // the WARM_EPISODES episodes after the last one opened (or the first ones
  // of a series not started yet) are searched and verified one at a time,
  // only while no listing is being answered and no other background search
  // runs. A full pass with nothing to do sleeps until something new is
  // watched (or an hour), so the shared store is not polled all day.
  server.startWarmer = ({ series = config.warmSeries, perSeries = config.warmEpisodes, intervalMs = config.warmIntervalSeconds * 1000, refreshMs = config.warmRefreshDays * 86400000, fetchImpl = fetch, idleMs = 3600000, recentRefreshMs = 3 * 3600000 } = {}) => {
    const episodeLists = new Map();
    const recent = new Set();
    let cursor = 0;
    let checkedSinceWork = 0;
    let sleepUntil = 0;
    const state = { warmed: 0, checked: 0, series: 0, episodes: 0, last: null };
    let running = false;
    const runTick = () => {
      if (running) return;
      running = true;
      tick().catch((error) => logger.warn("warm-up failed", { reason: error?.message || String(error) })).finally(() => { running = false; });
    };
    warmer.wake = () => {
      const wasSleeping = sleepUntil > Date.now();
      sleepUntil = 0;
      checkedSinceWork = 0;
      if (wasSleeping && !running && activeListings === 0) setImmediate(runTick);
    };
    async function episodesOf(id) {
      const known = episodeLists.get(id);
      if (known && Date.now() - known.at < 12 * 3600000) return known.list;
      const response = await fetchImpl(`https://v3-cinemeta.strem.io/meta/series/${id}.json`, { headers: { Accept: "application/json" }, signal: AbortSignal.timeout(15000) });
      if (!response.ok) throw new Error(`Cinemeta HTTP ${response.status}`);
      const videos = ((await response.json())?.meta?.videos || [])
        .filter((video) => Number(video.season) > 0 && Number(video.episode) > 0)
        // Episodes not aired yet have nothing to find.
        .filter((video) => !(Date.parse(video.released) > Date.now()))
        .sort((a, b) => a.season - b.season || a.episode - b.episode);
      const list = videos.map((video) => `${id}:${Number(video.season)}:${Number(video.episode)}`);
      // Aired in the last 14 days: Arabic fansubs often appear a day or two
      // later, so these are searched again every few hours.
      videos.forEach((video, index) => {
        if (Date.now() - Date.parse(video.released) < 14 * 86400000) recent.add(list[index]);
      });
      episodeLists.set(id, { at: Date.now(), list });
      return list;
    }
    async function queue() {
      const watching = (await choiceStore.get("watching").catch(() => null))?.series || {};
      const ids = [...new Set([...series, ...Object.keys(watching)])].filter((id) => /^tt\d{5,10}$/.test(id));
      const out = [];
      for (const id of ids) {
        const list = await episodesOf(id).catch(() => []);
        const last = watching[id];
        const at = last ? list.indexOf(`${id}:${last.season}:${last.episode}`) + 1 : 0;
        out.push(...list.slice(at, at + perSeries));
      }
      state.series = ids.length;
      state.episodes = out.length;
      return out;
    }
    async function tick() {
      if (Date.now() < sleepUntil || activeListings > 0 || refreshes.size > 0 || validations.size > 0) return;
      const episodes = await queue();
      if (!episodes.length) {
        sleepUntil = Date.now() + idleMs;
        return;
      }
      for (let scanned = 0; scanned < 25; scanned += 1) {
        cursor %= episodes.length;
        const videoId = episodes[cursor];
        cursor += 1;
        state.checked += 1;
        const key = searchKey("series", videoId, {});
        const entry = await searchStore.get(key);
        const fresh = entry && entry.complete && !identityUnresolved(entry.media) && Date.now() - (entry.updatedAt || 0) < (recent.has(videoId) ? Math.min(refreshMs, recentRefreshMs) : refreshMs);
        if (fresh) {
          checkedSinceWork += 1;
          if (checkedSinceWork >= episodes.length) {
            checkedSinceWork = 0;
            sleepUntil = Date.now() + idleMs;
            logger.info("warm-up pass complete", { episodes: episodes.length });
            return;
          }
          continue;
        }
        checkedSinceWork = 0;
        const media = entry?.media && !identityUnresolved(entry.media) ? entry.media : await alignMediaToFilename(await resolveVideoId("series", videoId), {});
        if (identityUnresolved(media)) continue;
        const work = scheduleRefresh(key, { media, extra: { filename: "", videoHash: "" } });
        if (work) {
          state.warmed += 1;
          state.last = videoId;
          logger.info("warm-up episode", { videoId });
        }
        return;
      }
    }
    const timer = setInterval(runTick, intervalMs);
    timer.unref?.();
    server.on("close", () => clearInterval(timer));
    server.warmState = state;
    return state;
  };

  server.flushBackground = async () => {
    for (const timer of retryTimers) clearTimeout(timer);
    retryTimers.clear();
    await Promise.allSettled([...backgroundTasks]);
    await Promise.allSettled([...storeLocks.values()]);
    await Promise.allSettled([searchStore.flush?.(), verdictStore.flush?.(), timingStore.flush?.(), choiceStore.flush?.()]);
  };
  server.on("close", () => {
    for (const timer of retryTimers) clearTimeout(timer);
  });
  server.stores = { search: searchStore, verdicts: verdictStore, timing: timingStore, choices: choiceStore };
  server.timingMemory = timingMemory;
  return server;
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const config = readConfig();
  if (config.tokenSecretGenerated) logger.warn("URL_TOKEN_SECRET is not set; signed subtitle URLs will change after restart");
  const server = await createAddonServer({ config });
  server.startWarmer();
  server.listen(config.port, config.host, () => {
    logger.info("Arabic Elite Subtitles started", { version: manifest.version, host: config.host, port: config.port, configure: `${config.publicBaseUrl || `http://127.0.0.1:${config.port}`}/configure` });
  });
  const shutdown = () => {
    server.close();
    Promise.race([server.flushBackground(), new Promise((resolve) => setTimeout(resolve, 4000))]).finally(() => process.exit(0));
  };
  process.on("SIGTERM", shutdown);
  process.on("SIGINT", shutdown);
}
